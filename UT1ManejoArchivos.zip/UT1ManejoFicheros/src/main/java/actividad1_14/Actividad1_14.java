/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_14;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class Actividad1_14 {
    public static void main(String[] args) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("fruta.txt"));
            bw.write("plátano\n");
            bw.write("manzana\n");
            bw.write("ciruela\n");
            bw.close();
            System.out.println("Hecho!");
        }catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero");
        }
    }
}
