/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_18;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class actividad1_18 {
    
    public static void main(String[] args) throws InterruptedException {
        
        File fichero = new File(args[0]);
        File fichero2 = new File(args[1] + ".tmp");
        
        if(!fichero2.exists()) {
            try{
                fichero2.createNewFile();
            }catch(IOException ioe2) {
                System.out.println("El fichero no se puede crear");
            }
        }
        
        try{
            BufferedReader br = new BufferedReader(new FileReader(fichero));
            BufferedReader br2 = new BufferedReader(new FileReader(fichero2));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fichero2));
            String linea = "";
            
            while(linea != null) {
               linea = br.readLine();
               if(linea != null) {
                   linea = linea.replace(' ', '-');
                   bw.write(linea);
                   br2.readLine();
               }
            }
            br.close();
            bw.close();
            Thread.sleep(6000);
            fichero2.delete();
            
        }catch(FileNotFoundException fnfe) {
            System.out.println("No se ha encontrado el fichero.");
        }catch(IOException ioe) {
            System.out.println("No tiene permisos para leer este fichero");
        }
        
    }
    
}
