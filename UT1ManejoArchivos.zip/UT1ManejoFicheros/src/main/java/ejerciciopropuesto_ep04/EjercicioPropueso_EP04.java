/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciopropuesto_ep04;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author 2dama
 */
public class EjercicioPropueso_EP04 {
    public static void main(String[] args) {
        String fichero = "./fichero1.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(fichero));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fichero + "_ordenado.txt"));
            String linea = "";
            ArrayList<String> lineasArchivo = new ArrayList();
            while(linea != null) {
                linea = br.readLine();
                lineasArchivo.add(linea);
            }
            String lineaSiguiente;
            for(int i = 0; i < lineasArchivo.size(); i++) {
                for(int z = 1; z < lineasArchivo.size()-1; z++) {
                    linea = lineasArchivo.get(i);
                    lineaSiguiente = lineasArchivo.get(z);
                    int comparador = 0;
                    int vueltas = 0;
                    while(comparador == 0) {
                        if(linea.charAt(vueltas) < lineaSiguiente.charAt(vueltas)) {
                            comparador = -1;
                        }else if(linea.charAt(vueltas) > lineaSiguiente.charAt(vueltas)) {
                            comparador = 1;
                        }
                        vueltas++;
                    }
                    switch(comparador) {
                        case 1:
                            lineasArchivo.remove(i);
                            lineasArchivo.add(z, linea);
                            break;
                        default:
                        }
                }
            bw.write(lineasArchivo.get(i));
            }
        }catch(FileNotFoundException fnfe){
            System.out.println("No se ha encontrado el fichero.");
        }catch(IOException ioe){
            System.out.println("No se ha podido leer el fichero");
        }
    }
}
