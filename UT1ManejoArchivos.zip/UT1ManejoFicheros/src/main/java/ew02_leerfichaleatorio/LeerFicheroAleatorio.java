/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ew02_leerfichaleatorio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author 2dama
 */
public class LeerFicheroAleatorio {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File fichero = new File("AleatorioEmple.dat");
        RandomAccessFile file = new RandomAccessFile(fichero, "r");
        
        int dep;
        double salario;
        char apellido[] = new char[10], aux;
        int posicion = 0;
        
        String str = " ";
        String lineaID = "ID:" + str.repeat(2);
        String lineaApellidos = "Apellidos:" + str.repeat(4);
        String lineaDpto = "Departamento: " + str.repeat(2);
        String lineaSalario = "Salario: " + str.repeat(2);
        
        System.out.println(lineaID + lineaApellidos + lineaDpto + lineaSalario);
        System.out.println("------------------------------------------------------------------------");
        
        while (posicion < file.length()) {
            file.seek(posicion);
            int id = file.readInt();
            
            for(int i = 0; i < apellido.length; i++) {
                aux = file.readChar();
                apellido[i] = aux;
            }
            
            String apellidoS = new String(apellido);
            dep = file.readInt();
            salario = file.readDouble();
            
            System.out.println(
                    id 
                    + str.repeat(lineaID.length() - String.valueOf(id).length()) 
                    + apellidoS.trim() 
                    + str.repeat(lineaApellidos.length() - apellidoS.trim().length())  
                    + dep 
                    + str.repeat(lineaDpto.length() - String.valueOf(dep).length()) 
                    + salario 
                    + str.repeat(lineaSalario.length() - String.valueOf(salario).length()));
            
            posicion += 36;
        }
        file.close();
    }
}
