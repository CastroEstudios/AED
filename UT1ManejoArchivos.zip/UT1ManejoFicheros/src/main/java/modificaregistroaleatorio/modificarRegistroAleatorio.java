/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modificaregistroaleatorio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

/**
 *
 * @author 2dama
 */
public class modificarRegistroAleatorio {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        File fichero = new File("AleatorioEmple.dat");
        RandomAccessFile file = new RandomAccessFile(fichero, "rw");
        escribirFichero(file);
        file.close();
    }
    
    private static void escribirFichero(RandomAccessFile file) {
        System.out.print("Introduca el número del registro a modificar: ");
        System.out.println("");
        Scanner s = new Scanner(System.in);
        int posicion = s.nextInt();

        System.out.print("Introduzca el número del nuevo departamento");
        System.out.println("");
        int dep = s.nextInt();
        System.out.print("Introduzca el nuevo salario: ");
        System.out.println("");
        double salario = s.nextDouble();
        System.out.print("Introduzca el nuevo apellido: ");
        System.out.println("");
        s.nextLine();
        String apellidoC = s.nextLine();
        s.close();
        try {
            file.seek(posicion);
            file.readInt();

            file.writeChars(apellidoC);
            file.writeInt(dep);
            file.writeDouble(salario);
        }catch(IOException ioe) {
            ioe.getMessage();
        }
    }
}
