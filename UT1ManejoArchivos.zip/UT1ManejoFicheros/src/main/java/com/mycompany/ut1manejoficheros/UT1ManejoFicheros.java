/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut1manejoficheros;

import java.io.File;

/**
 *
 * @author 2dama
 */
public class UT1ManejoFicheros {

    public static void main(String[] args) {
        File fichero = new File("C:\\Windows");
        UT1ManejoFicheros prueba = new UT1ManejoFicheros();
        prueba.listarFicheros(fichero);
    }
    
    public void listarFicheros(File fichero) {
        File[] listaFicheros = fichero.listFiles();
        int numFicheros = listaFicheros.length;
        for (int i = 0; i < numFicheros; i++) {
            if(listaFicheros[i].isDirectory()) {
                System.out.print("+");
            }
            System.out.println(listaFicheros[i].getName());
        }
    }
}
