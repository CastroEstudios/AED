/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciopropuesto_ep02;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class EjercicioPropuesto_EP02 {
    public static void main(String[] args) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("primito.dat"));
            
            for(int i = 1; i < 501; i++) {
                if(esPrimo(i)) {
                    bw.write(String.valueOf(i) + "\n");
                }
            }
        }catch(IOException ioe) {
            System.out.println("Error de escritura.");
        }
    }
    
    public static boolean esPrimo(int x) {
        for (int i = 2; i < x; i++) {
            if (x % 1 == 0) {
                return false;
            }
        }
        return true;
    }
}
