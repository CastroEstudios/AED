package ejerciciopropuesto_ep05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
public class EjercicioPropuesto_EP05nocomentarios {

    public static void main(String[] args) {
        File fichero = new File("src\\main\\java\\ejerciciopropuesto_ep05\\EjercicioPropuesto_EP05nocomentarios.java");
        try {
            BufferedReader br = new BufferedReader(new FileReader(fichero));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fichero 
                    + ".javanocomentarios.java"));
            String linea = "";
            ArrayList<String> lineasNuevoArchivo;
            lineasNuevoArchivo = new ArrayList();
            while (linea != null) {
                linea = br.readLine();
                if (linea != null) {
                        lineasNuevoArchivo.add(linea);
                    }else if (linea.contains("/*")) {
                        while (!linea.contains("*/")) {
                            linea = br.readLine();
                        }
                    }else if(linea.contains("EjercicioPropuesto_EP05nocomentarios")) {
                        linea = linea.replace("EjercicioPropuesto_EP05nocomentarios"
                                , "EjercicioPropuesto_EP05nocomentariosnocomentarios");
                        lineasNuevoArchivo.add(linea);
                    }else if (!linea.contains("//")) {
                        lineasNuevoArchivo.add(linea);
                    }
                }
            }
            for (String lineaArchivo : lineasNuevoArchivo) {
                bw.write(lineaArchivo + "\n");
            }
            bw.close();
            br.close();
        } catch (FileNotFoundException fnfe) {
            System.out.println("Nos hundimosglgulgglu");
        } catch (IOException ioe) {
            System.out.println("Todo malardo amigo");
        }
    }
}
