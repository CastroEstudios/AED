/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_15_1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author 2dama
 */
public class Actividad1_15_1 {
    public static void main(String[] args) {
        try {
            Scanner s = new Scanner(System.in);
            System.out.println("Introduzca la ruta del fichero con el que operar: ");
            String ruta = s.nextLine();
            BufferedReader br = new BufferedReader(new FileReader(ruta));
            String linea = "";
            int numLineas = 0;
            double suma = 0;
            while(linea != null) {
                try{
                    linea = br.readLine();
                    if(linea != null) {
                        suma += Integer.parseInt(linea);
                        numLineas++;
                    }
                }catch(IOException ioe){
                    System.out.println("Pasaron cositas");
                }
            }
            double media = suma/numLineas;
            System.out.println("La media de los números es: " + media);
        }catch(FileNotFoundException fnfe) {
            System.out.println("No se ha encontrado el archivo");
        }
    }
}
