/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciopropuesto_ep01;

/**
 *
 * @author 2dama
 */
public class EjercicioPropuesto_EP01 {
    public static void main(String[] args) {
        int numInicial = 1;
        int numMax = 1000;
        int resultado1 = 0;
        int resultado2 = 0;
        System.out.println("""
                           1
                           2
                           3
                           """);
        for(int contadorI = numInicial; contadorI < numMax && resultado2 < 1000
                ; contadorI++) {
            resultado1 = 6*contadorI-1;
            System.out.println(resultado1);
            resultado2 = 6*contadorI+1;
            System.out.println(resultado2);
        }
    }
}
