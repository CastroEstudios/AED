/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_15;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class actividad1_15 {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("numeros.txt"));
            String linea = "";
            int numLineas = 0;
            double suma = 0;
            while(linea != null) {
                try{
                    linea = br.readLine();
                    if(linea != null) {
                        suma += Integer.parseInt(linea);
                        numLineas++;
                    }
                }catch(IOException ioe){
                    System.out.println("Pasaron cositas");
                }
            }
            double media = suma/numLineas;
            System.out.println("La media de los números es: " + media);
        }catch(FileNotFoundException fnfe) {
            System.out.println("No se ha encontrado el archivo");
        }
    }
}
