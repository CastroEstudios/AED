/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package leerfichaleatoriounreg;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author 2dama
 */
public class LeerFichAleatorioUnReg {
    public static void main(String[] args) throws IOException {
        File fichero = new File("AleatorioEmple.dat");
        RandomAccessFile file = new RandomAccessFile(fichero, "r");
        
        int id, dep, posicion;
        Double salario;
        char apellido[] = new char[10], aux;
        int registro = Integer.parseInt(args[0]);
        
        posicion = (registro - 1) * 36;
        if(posicion >= file.length())
            System.out.printf("ID: %d, NO EXISTE EMPLEADO...", registro);
        else {
            file.seek(posicion);
            id = file.readInt();
            for(int i = 0; i < apellido.length; i++) {
                aux = file.readChar();
                apellido[i] = aux;
            }
            String apellidoS = new String(apellido);
            dep = file.readInt();
            salario = file.readDouble();
            
            System.out.println("ID: " + registro + ", Apellido: " 
                    + apellidoS.trim() + ", Departamento: " + dep 
                    + ", Salario: " + salario);
        }
        file.close();
    }
}
