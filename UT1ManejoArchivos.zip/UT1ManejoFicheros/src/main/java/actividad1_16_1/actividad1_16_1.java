/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_16_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class actividad1_16_1 {
    public static void main(String[] args) {
        File fichero1 = new File(args[0]);
        File fichero2 = new File(args[1]);
        File fichero3 = new File(args[2]);
        try {
            BufferedReader br = new BufferedReader(new FileReader(fichero1));
            BufferedReader br2 = new BufferedReader(new FileReader(fichero2));
            BufferedWriter bw = new BufferedWriter(new FileWriter(fichero3));
            
            String linea1 = "";
            String linea2 = "";
            
            while(linea1 != null || linea2 != null) {
                linea1 = br.readLine();
                if(linea1 != null) {
                    bw.write(linea1 + "\n");
                }
                linea2 = br2.readLine();
                if(linea2 != null) {
                    bw.write(linea2 + "\n");
                }
            }
            
            br.close();
            br2.close();
            bw.close();
        }catch(FileNotFoundException fnfe){
            System.out.println("Lo siento bebé");
        }catch(IOException ioe){
            System.out.println("No tiene permisos para acceder a alguno de los archivos.");
        }
    }
}

