/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_17;

/**
 *
 * @author 2dama
 */
public class actividad1_17 {
    
    public static void main(String[] args) {
        System.out.println("\nEjemplo1");
        System.out.println("En la posición 2 de \"berengena\" está la letra " 
            + "berengena".charAt(2));
        System.out.println("\nEjemplo2");
        String frase = "Hola caracola.";
        System.out.println("La secuencia \"co\" aparece en la frase en la posición "
            + frase.indexOf("co"));
        System.out.println("\nEjemplo 3");
        System.out.println("La palabra \"muerciélago\" tiene "
            + "murciélago".length() + " letras");
        System.out.println("\nEjemplo 4");
        String frase2 = frase.replace('o', 'u');
        System.out.println(frase2);
        System.out.println("\nEjemplo5");
        frase2 = frase.substring(3, 10) + frase.substring(13);
        System.out.println(frase2);
        System.out.println("\nEjemplo 6");
        System.out.println(frase.toLowerCase());
        System.out.println("\nEjemplo7");
        System.out.println(frase.toUpperCase());
    }
    
}
