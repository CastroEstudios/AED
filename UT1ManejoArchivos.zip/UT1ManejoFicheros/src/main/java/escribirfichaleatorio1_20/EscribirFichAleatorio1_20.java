/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escribirfichaleatorio1_20;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 *
 * @author 2dama
 */
public class EscribirFichAleatorio1_20 {
    public static void main(String[] args) {
        ArrayList<ProductoClase> productos = new ArrayList();
        productos.add(new ProductoClase(1, "producto 1 se trunca a 10 bytes", 10.5, true, 'T'));
        productos.add(new ProductoClase(2, "producto 2", 50.5, true, 'R'));
        productos.add(new ProductoClase(3, "producto 3", 10.5, false, 'T'));
        productos.add(new ProductoClase(4, "producto 4", 30.5, true, 'B'));
        productos.add(new ProductoClase(5, "prodcuto 5", 20.5, true, 'T'));
        try(
            RandomAccessFile raf = new RandomAccessFile("ejemplo_raf.dat", "rw")) {
                for(ProductoClase pc : productos) {
                    raf.writeInt(pc.getId());
                    StringBuffer sb = new StringBuffer(pc.getNombre());
                    sb.setLength(10);
                    raf.writeChars(sb.toString());
                    raf.writeDouble(pc.getPrecio());
                    raf.writeBoolean(pc.isDescuento());
                    raf.writeChar(pc.getTipo());

                } 
                System.out.println("Introduzca el número de registro a leer");
                Scanner s = new Scanner(System.in);
                int numRegistro = s.nextInt();
                raf.seek(numRegistro);

                System.out.println(raf.readInt());
                String nombre = "";
                for(int i = 0; i < 10; i++) {
                    nombre += raf.readChar();
                }
                System.out.println(nombre);
                System.out.println(raf.readDouble());
                System.out.println(raf.readBoolean());
                System.out.println(raf.readChar());

        }catch(FileNotFoundException fnfe) {
            System.out.println(fnfe.getMessage());
        }catch(IOException ioe) {
            System.out.println(ioe.getMessage());
        }
    }
}
