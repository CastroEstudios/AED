/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad1_13;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author 2dama
 */
public class Actividad1_13 {

    public static void main(String[] args) {

        try {
            BufferedReader br = new BufferedReader(new FileReader("tenerife.txt"));
            String linea = "";

            while (linea != null) {
                System.out.println(linea);
                linea = br.readLine();
            }
            br.close();

        } catch (FileNotFoundException fnfe) {
            System.out.println("No se encuentra el fichero.");
        } catch (IOException ioe) {
            System.out.println("No se puede leer el fichero.");
        }
    }

}
